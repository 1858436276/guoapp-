// 自动生成 · 多模式抓取版
const CONFIG = {
  "baseUrl": "https://dongpian.ai",
  "domain": "dongpian.ai",
  "userAgent": "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X)",
  "cookie": "",
  "categories": [
    {
      "id": "1",
      "name": "全部"
    }
  ],
  "defaultCategory": "1",
  "useJson": false,
  "jsonSources": [],
  "itemHrefPattern": "\\/detail\\/(\\d+)\\.html",
  "itemIdPattern": "\\/detail\\/(\\d+)\\.html",
  "detailUrl": "/detail/{id}.html",
  "catalogUrlList": [
    "/type/{id}-{page}.html",
    "/vodtype/{id}-{page}.html",
    "/list/{id}-{page}.html",
    "/vodshow/{id}--------{page}---.html",
    "/category/{id}/page/{page}"
  ],
  "catalogFirstPageList": [
    "/",
    "/index.php"
  ],
  "searchUrlList": [
    "/index.php/vod/search.html?wd={kw}&page={page}",
    "/index.php/vod/search/page/{page}/wd/{kw}.html",
    "/vodsearch/{kw}----------{page}---.html",
    "/search.php?searchword={kw}&page={page}",
    "/search?q={kw}&page={page}"
  ],
  "playHrefPattern": "(?:play|vodplay|video|bofang|kan|v)\\/[^\"'#?]*\\d"
};
const BASE_URL = CONFIG.baseUrl;
const DEFAULT_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1";

function absUrl(ref, base) {
  ref = String(ref || "").trim();
  if (ref === "") return "";
  if (/^https?:\/\//i.test(ref)) return ref;
  if (ref.indexOf("//") === 0) return "https:" + ref;
  const b = base || BASE_URL;
  if (ref.charAt(0) === "/") { const m = b.match(/^https?:\/\/[^\/]+/i); return m ? m[0] + ref : ref; }
  return b.replace(/\/+$/, "") + "/" + ref;
}

function unescapeHtml(s) {
  return String(s || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ").replace(/&#x([0-9a-f]+);/gi, function (m, c) { return String.fromCharCode(parseInt(c, 16)); }).replace(/&#(\d+);/g, function (m, c) { return String.fromCharCode(parseInt(c, 10)); });
}

function pickAttr(tag, names) {
  for (let i = 0; i < names.length; i++) {
    const re = new RegExp("\\b" + names[i] + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", "i");
    const m = String(tag).match(re);
    if (m) { const v = (m[2] || m[3] || m[4] || "").trim(); if (v !== "") return unescapeHtml(v); }
  }
  return "";
}

function eachAnchor(html, cb) {
  const re = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const href = pickAttr(m[1], ["href"]);
    if (!href) continue;
    const imgTag = (m[2].match(/<img\b[^>]*>/i) || [""])[0];
    cb({ href, title: pickAttr(m[1], ["title"]), img: imgTag ? pickAttr(imgTag, ["data-original", "data-src", "data-lazy-src", "src"]) : "", text: unescapeHtml(m[2].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim() });
  }
}

function fetchHtml(path) {
  const url = absUrl(path);
  const headers = { "User-Agent": CONFIG.userAgent || DEFAULT_UA, "Accept-Language": "zh-CN,zh;q=0.9" };
  if (CONFIG.cookie) headers["Cookie"] = CONFIG.cookie;
  const resp = host.fetchText({ url, referer: BASE_URL + "/", headers });
  const body = resp && typeof resp.body === "string" ? resp.body : String(resp || "");
  if (body.trim() === "") throw new Error("页面为空：" + url);
  return body;
}

function extractJsonBlocks(html) {
  const out = [];
  (CONFIG.jsonSources || []).forEach(s => {
    if (s.kind === "selector" && s.selector) {
      const id = s.selector.replace(/^.*#/, "");
      const m = html.match(new RegExp("<script[^>]*id=[\"']" + id + "[\"'][^>]*>([\\s\\S]*?)<\\/script>", "i"));
      if (m) try { out.push(JSON.parse(m[1])); } catch (e) {}
    } else if (s.kind === "regex" && s.pattern) {
      const m = html.match(new RegExp(s.pattern, "i"));
      if (m && m[1]) try { out.push(JSON.parse(m[1])); } catch (e) {}
    }
  });
  return out;
}

function findDramasInJson(obj, depth) {
  depth = depth || 0;
  if (depth > 9 || !obj) return null;
  if (Array.isArray(obj)) {
    if (obj.length > 0 && obj.length < 800) {
      const f = obj[0];
      if (f && typeof f === "object" && !Array.isArray(f)) {
        const ks = Object.keys(f);
        if (ks.some(k => /^(vod_name|name|title|video_name|videoTitle)$/i.test(k)) && ks.some(k => /^(vod_id|id|video_id|videoId|slug|uuid)$/i.test(k))) return obj;
      }
    }
    for (const i of obj) { const r = findDramasInJson(i, depth + 1); if (r) return r; }
  } else if (typeof obj === "object") {
    for (const k of Object.keys(obj)) { const r = findDramasInJson(obj[k], depth + 1); if (r) return r; }
  }
  return null;
}

function mapJsonItem(item, pageUrl) {
  const pick = keys => { for (const k of keys) if (item[k] != null && String(item[k]).trim() !== "") return String(item[k]).trim(); return ""; };
  const sid = pick(["vod_id", "id", "video_id", "videoId", "slug", "uuid"]);
  const title = pick(["vod_name", "name", "title", "video_name", "videoTitle"]);
  if (!sid || !title) return null;
  let cover = pick(["vod_pic", "cover", "coverUrl", "image", "poster", "thumbnail"]);
  cover = cover ? absUrl(cover, pageUrl) : "";
  let remark = pick(["vod_remarks", "remark", "remarks", "note"]);
  const total = pick(["total_episodes", "episode_count", "totalEpisode", "episodes", "vod_total"]);
  if (!remark && total) remark = "全" + total + "集";
  return { id: host.dramaId(sid), source: host.source, sourceId: sid, title, name: title, desc: pick(["vod_content", "description", "desc", "intro"]).slice(0, 300), intro: pick(["vod_content", "description", "desc", "intro"]).slice(0, 300), cover, coverUrl: cover, totalEpisode: total, episodeCount: total, categoryName: pick(["cate_name", "category", "type_name"]), remark, score: pick(["vod_score", "score", "rating"]), views: "", onlineDate: pick(["vod_pubdate", "pubdate", "release_date"]), releaseStatus: "" };
}

function pickTitle(a) {
  for (const c of [a.title, a.text]) {
    let t = String(c || "").replace(/\s+/g, " ").trim();
    if (!t || /^(首页|登录|注册|搜索|更多|全部|立即播放|播放|下载|详情|查看)$/.test(t)) continue;
    t = t.replace(/^(更新至|全)\s*/, "").trim();
    return t.length > 80 ? t.slice(0, 80) : t;
  }
  return "";
}

function pickRemark(text) { const m = String(text || "").match(/(?:更新至?\s*\d+\s*集?|全\s*\d+\s*集?|第\s*\d+\s*集|完结|HD\d*|蓝光)/); return m ? m[0] : ""; }

function parseListFromHtml(html, pageUrl) {
  const items = [], seen = new Set();
  let hrefRe, idRe;
  try { hrefRe = new RegExp(CONFIG.itemHrefPattern, "i"); } catch (e) { hrefRe = null; }
  try { idRe = new RegExp(CONFIG.itemIdPattern, "i"); } catch (e) { idRe = null; }
  eachAnchor(html, a => {
    if (hrefRe && !hrefRe.test(a.href)) return;
    const m = idRe ? a.href.match(idRe) : null;
    if (!m || !m[1] || seen.has(String(m[1]).trim())) return;
    const sid = String(m[1]).trim(), title = pickTitle(a);
    if (!title) return;
    seen.add(sid);
    const cover = a.img ? absUrl(a.img, pageUrl) : "";
    items.push({ id: host.dramaId(sid), source: host.source, sourceId: sid, title, name: title, desc: "", intro: "", cover, coverUrl: cover, totalEpisode: "", episodeCount: "", categoryName: "", remark: pickRemark(a.text), score: "", views: "", onlineDate: "", releaseStatus: "" });
  });
  return items;
}

function parseList(html, pageUrl) {
  if (CONFIG.useJson) {
    for (const b of extractJsonBlocks(html)) {
      const arr = findDramasInJson(b);
      if (arr && arr.length > 0) {
        const mapped = [], seen = new Set();
        for (const i of arr) { const d = mapJsonItem(i, pageUrl); if (d && !seen.has(d.sourceId)) { seen.add(d.sourceId); mapped.push(d); } }
        if (mapped.length > 0) return mapped;
      }
    }
  }
  return parseListFromHtml(html, pageUrl);
}

function detectHasMore(html, page) {
  return ["[-_/]" + (page+1) + "\\.html", "page[/-]?" + (page+1) + "(?:[/?#\"']|$)", ">\\s*" + (page+1) + "\\s*<"].some(p => { try { return new RegExp(p).test(html); } catch (e) { return false; } });
}

function fetchFirstHit(templates, catId, page) {
  const errors = [];
  for (const t of templates) {
    const path = t.replace(/\{id\}/g, catId).replace(/\{page\}/g, String(page));
    let html;
    try { html = fetchHtml(path); } catch (e) { errors.push(path + ": " + e.message); continue; }
    const items = parseList(html, path);
    if (items.length > 0) return { path, html, items };
    errors.push(path + ": 无条目");
  }
  throw new Error("目录解析失败：" + errors.join(" | "));
}

function parseDetailFromHtml(html, pageUrl, sourceId) {
  let title = "";
  let m = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']*)["']/i) || html.match(/<meta[^>]+content=["']([^"']*)["'][^>]+property=["']og:title["']/i);
  if (m) title = unescapeHtml(m[1]);
  if (!title && (m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i))) title = unescapeHtml(m[1].replace(/<[^>]+>/g, "")).trim();
  if (!title && (m = html.match(/<title>([\s\S]*?)<\/title>/i))) title = unescapeHtml(m[1]).replace(/[-_|–—].*$/, "").trim();
  title = String(title || "").replace(/\s+/g, " ").trim();
  let cover = "";
  if ((m = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']*)["']/i))) cover = absUrl(m[1], pageUrl);
  if (!cover) { const tag = (html.match(/<img\b[^>]*(?:class|id)=["'][^"']*(?:pic|cover|poster|thumb)[^"']*["'][^>]*>/i) || [""])[0]; if (tag) cover = absUrl(pickAttr(tag, ["data-original", "data-src", "src"]), pageUrl); }
  let intro = "";
  m = html.match(/<div[^>]*class=["'][^"']*(?:desc|content|intro|juqing|jj)[^"']*["'][^>]*>([\s\S]*?)<\/div>/i) || html.match(/<p[^>]*class=["'][^"']*(?:desc|content|intro|juqing|jj)[^"']*["'][^>]*>([\s\S]*?)<\/p>/i);
  if (m) { intro = unescapeHtml(m[1].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim(); if (intro.length > 500) intro = intro.slice(0, 500); }
  let totalEp = ""; if ((m = html.match(/(?:更新至|全)\s*(\d+)\s*集/))) totalEp = m[1];
  return { id: host.dramaId(sourceId), source: host.source, sourceId, title: title || sourceId, name: title || sourceId, desc: intro, intro, cover, coverUrl: cover, totalEpisode: totalEp, episodeCount: totalEp, categoryName: "", remark: totalEp ? ("全" + totalEp + "集") : "", score: "", views: "", onlineDate: "", releaseStatus: "" };
}

function extractEpNum(text) { const m = String(text || "").match(/(?:第\s*)?0*(\d+)\s*(?:集|话|期)?/); return m ? parseInt(m[1], 10) : 0; }

function parseChaptersFromHtml(html, pageUrl, sourceId) {
  let playRe; try { playRe = new RegExp(CONFIG.playHrefPattern, "i"); } catch (e) { playRe = /(?:play|vodplay|video)\/\d/i; }
  const list = [], seen = new Set();
  eachAnchor(html, a => {
    if (!playRe.test(a.href)) return;
    const text = a.text.replace(/\s+/g, "");
    if (/^(立即播放|播放|下载|上一集|下一集|报错|收藏|分享|详情)$/.test(text)) return;
    if (!/\d/.test(a.href) && !/\d/.test(text)) return;
    if (seen.has(a.href)) return;
    seen.add(a.href);
    list.push({ href: absUrl(a.href, pageUrl), title: text || a.title || "", episode: extractEpNum(text) });
  });
  if (list.length === 0) {
    const dUrl = absUrl((CONFIG.detailUrl || "/detail/{id}.html").replace(/\{id\}/g, sourceId));
    return [{ id: host.chapterId(sourceId, "1"), source: host.source, title: "正片", pageUrl: dUrl, currentEpisode: 1 }];
  }
  const numbered = list.every(x => x.episode > 0);
  const ordered = numbered && list.length > 1 ? list.slice().sort((x, y) => x.episode - y.episode) : list;
  return ordered.map((x, i) => ({ id: host.chapterId(sourceId, x.href), source: host.source, title: x.title || ("第" + (i + 1) + "集"), pageUrl: x.href, currentEpisode: x.episode > 0 ? x.episode : (i + 1) }));
}

function parseChaptersFromJson(blocks, pageUrl, sourceId) {
  function walk(obj, d) {
    d = d || 0;
    if (d > 8 || !obj) return null;
    if (typeof obj === "object") {
      if (obj.vod_play_url && typeof obj.vod_play_url === "string") return obj;
      if (Array.isArray(obj.episodes) && obj.episodes.length > 0) return obj;
      if (Array.isArray(obj.playlist) && obj.playlist.length > 0) return obj;
      for (const k of Object.keys(obj)) { const r = walk(obj[k], d + 1); if (r) return r; }
    }
    return null;
  }
  for (const b of blocks) {
    const node = walk(b);
    if (!node) continue;
    if (node.vod_play_url) {
      const out = [];
      String(node.vod_play_url).split("$$$")[0].split("#").forEach((part, idx) => {
        const seg = part.split("$");
        if (seg.length >= 2 && /^https?:/i.test(seg[1])) out.push({ id: host.chapterId(sourceId, "ep" + (idx + 1)), source: host.source, title: seg[0] || ("第" + (idx + 1) + "集"), pageUrl: absUrl(seg[1], pageUrl), currentEpisode: idx + 1 });
      });
      if (out.length > 0) return out;
    }
    const eps = node.episodes || node.playlist;
    if (Array.isArray(eps)) {
      const out = [];
      eps.forEach((ep, idx) => {
        const url = ep.url || ep.play_url || ep.src || ep.href || "";
        if (url) out.push({ id: host.chapterId(sourceId, "ep" + (idx + 1)), source: host.source, title: ep.title || ep.name || ("第" + (idx + 1) + "集"), pageUrl: absUrl(url, pageUrl), currentEpisode: idx + 1 });
      });
      if (out.length > 0) return out;
    }
  }
  return null;
}

function legacyUnescape(s) { return String(s || "").replace(/%u([0-9a-f]{4})/gi, (m, c) => String.fromCharCode(parseInt(c, 16))).replace(/%([0-9a-f]{2})/gi, (m, c) => String.fromCharCode(parseInt(c, 16))); }
function tryBase64(text) { if (!text) return ""; try { return host.base64Decode(text); } catch (e) { return ""; } }

function extractPlayerUrl(html, depth) {
  depth = depth || 0; html = String(html || "").replace(/\\\//g, "/");
  let m = html.match(/var\s+player_aaaa\s*=\s*(\{[\s\S]*?\})\s*;?\s*<\/script>/i) || html.match(/player_aaaa\s*=\s*(\{[\s\S]*?\});/i);
  if (m) {
    let data = null; try { data = JSON.parse(m[1]); } catch (e) {}
    if (data && data.url) {
      let url = String(data.url), enc = Number(data.encrypt) || 0;
      if (enc === 1) url = tryBase64(url); else if (enc === 2) url = tryBase64(legacyUnescape(url));
      if (/^https?:\/\//i.test(url)) return url;
    }
  }
  m = html.match(/https?:\/\/[^\s"'<>\\]+\.(?:m3u8|mp4)[^\s"'<>\\]*/i) || html.match(/["'](?:url|src|file|play_url)["']\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/i);
  if (m) return m[1] || m[0];
  if (depth < 2) {
    const f = html.match(/<iframe[^>]+src=["']([^"']+)["']/i);
    if (f) { try { const found = extractPlayerUrl(fetchHtml(absUrl(f[1])), depth + 1); if (found) return found; } catch (e) {} }
  }
  return "";
}

module.exports = {
  categories: () => CONFIG.categories.map(c => ({ id: c.id, name: c.name })),
  validCategory: c => !c || CONFIG.categories.some(x => x.id === String(c)),
  catalogPage: function (page, category) {
    const catId = !category ? CONFIG.defaultCategory : String(category);
    const tpls = page === 1 ? (CONFIG.catalogFirstPageList || []).concat(CONFIG.catalogUrlList || []) : (CONFIG.catalogUrlList || []);
    const r = fetchFirstHit(tpls, catId, page);
    return { items: r.items, hasMore: detectHasMore(r.html, page) };
  },
  search: function (page, query) {
    query = String(query || "").trim(); if (!query) return { items: [], hasMore: false };
    const errors = [];
    for (const t of (CONFIG.searchUrlList || [])) {
      const path = t.replace(/\{kw\}/g, encodeURIComponent(query)).replace(/\{page\}/g, String(page));
      let html; try { html = fetchHtml(path); } catch (e) { errors.push(path + ": " + e.message); continue; }
      const items = parseList(html, path);
      if (items.length > 0) return { items, hasMore: detectHasMore(html, page) };
      errors.push(path + ": 无结果");
    }
    throw new Error("搜索失败：" + errors.join(" | "));
  },
  detail: function (sourceId) {
    sourceId = String(sourceId || "").trim().replace(/^\/+|\/+$/g, "");
    if (!/^[a-zA-Z0-9_-]+$/.test(sourceId)) throw new Error("无效的剧集 ID");
    const path = (CONFIG.detailUrl || "/detail/{id}.html").replace(/\{id\}/g, sourceId);
    const html = fetchHtml(path);
    let drama = null, chapters = null;
    if (CONFIG.useJson) {
      const blocks = extractJsonBlocks(html);
      for (const b of blocks) {
        const arr = findDramasInJson(b);
        if (arr && arr.length > 0) {
          for (const i of arr) { const d = mapJsonItem(i, path); if (d && d.sourceId === sourceId) { drama = d; break; } }
        }
        if (drama) { chapters = parseChaptersFromJson(blocks, path, sourceId); break; }
      }
    }
    if (!drama) drama = parseDetailFromHtml(html, path, sourceId);
    if (!chapters || chapters.length === 0) chapters = parseChaptersFromHtml(html, path, sourceId);
    return { drama, chapters };
  },
  resolveMedia: function (task) {
    const pageUrl = task && task.chapter && task.chapter.pageUrl ? String(task.chapter.pageUrl) : "";
    if (!pageUrl) throw new Error("缺少播放页地址");
    const html = fetchHtml(pageUrl);
    const media = extractPlayerUrl(html, 0);
    if (!media) throw new Error("未解析到 m3u8/mp4 地址");
    return host.finishMedia({ url: media, referer: pageUrl });
  }
};